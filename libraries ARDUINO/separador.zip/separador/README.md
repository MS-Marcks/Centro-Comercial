Libreria-Plantilla-Arduino
==========================

Librería plantilla para hacer tu propia librería de Arduino.
***Esta es una librería de ejemplo creada para Arduino, basada en la creada por Nicholas Zambetti para Wiring 006***
***Para instalar esta librería, descomprimir el archivo en el nuestro sketchbook de Arduino, que podréis comprobar abriendo el IDE de Arduino y en Archivo/Preferencias/***
***Para comprobar que está correctamente instalada, dentro del IDE de Arduino ir a Sketch/Importar librería y comprobar que aparece "Libejemplo".***
***Nota importante: está librería no cumple ninguna función, ya que sólo es una plantilla para facilitar el trabajo a los programadores.***
***La librería ha sido creada por A.Girod, de Opiron Electronics en www.opiron.com****
***La librería es de dominio público***
